﻿namespace KURZBEIN_DATENERFASSUNG
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.labelGenre = new System.Windows.Forms.Label();
            this.labelOriginaltitel = new System.Windows.Forms.Label();
            this.labelErscheinungsjahr = new System.Windows.Forms.Label();
            this.labelAutor = new System.Windows.Forms.Label();
            this.labelTitel = new System.Windows.Forms.Label();
            this.textBoxGenre = new System.Windows.Forms.TextBox();
            this.textBoxOriginaltitel = new System.Windows.Forms.TextBox();
            this.textBoxErscheinungsjahr = new System.Windows.Forms.TextBox();
            this.textBoxAutor = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnAbbrechen = new System.Windows.Forms.Button();
            this.btnSpeichern = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.textBoxTitel = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.MediumPurple;
            this.panel1.Controls.Add(this.labelGenre);
            this.panel1.Controls.Add(this.labelOriginaltitel);
            this.panel1.Controls.Add(this.labelErscheinungsjahr);
            this.panel1.Controls.Add(this.labelAutor);
            this.panel1.Controls.Add(this.labelTitel);
            this.panel1.Controls.Add(this.textBoxGenre);
            this.panel1.Controls.Add(this.textBoxOriginaltitel);
            this.panel1.Controls.Add(this.textBoxErscheinungsjahr);
            this.panel1.Controls.Add(this.textBoxAutor);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.btnAbbrechen);
            this.panel1.Controls.Add(this.btnSpeichern);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.textBoxTitel);
            this.panel1.Location = new System.Drawing.Point(15, 16);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(786, 422);
            this.panel1.TabIndex = 0;
            // 
            // labelGenre
            // 
            this.labelGenre.AutoSize = true;
            this.labelGenre.Location = new System.Drawing.Point(291, 325);
            this.labelGenre.Name = "labelGenre";
            this.labelGenre.Size = new System.Drawing.Size(36, 13);
            this.labelGenre.TabIndex = 15;
            this.labelGenre.Text = "Genre";
            // 
            // labelOriginaltitel
            // 
            this.labelOriginaltitel.AutoSize = true;
            this.labelOriginaltitel.Location = new System.Drawing.Point(288, 256);
            this.labelOriginaltitel.Name = "labelOriginaltitel";
            this.labelOriginaltitel.Size = new System.Drawing.Size(58, 13);
            this.labelOriginaltitel.TabIndex = 14;
            this.labelOriginaltitel.Text = "Originaltitel";
            // 
            // labelErscheinungsjahr
            // 
            this.labelErscheinungsjahr.AutoSize = true;
            this.labelErscheinungsjahr.Location = new System.Drawing.Point(288, 192);
            this.labelErscheinungsjahr.Name = "labelErscheinungsjahr";
            this.labelErscheinungsjahr.Size = new System.Drawing.Size(88, 13);
            this.labelErscheinungsjahr.TabIndex = 13;
            this.labelErscheinungsjahr.Text = "Erscheinungsjahr";
            // 
            // labelAutor
            // 
            this.labelAutor.AutoSize = true;
            this.labelAutor.Location = new System.Drawing.Point(288, 135);
            this.labelAutor.Name = "labelAutor";
            this.labelAutor.Size = new System.Drawing.Size(32, 13);
            this.labelAutor.TabIndex = 12;
            this.labelAutor.Text = "Autor";
            // 
            // labelTitel
            // 
            this.labelTitel.AutoSize = true;
            this.labelTitel.Location = new System.Drawing.Point(288, 80);
            this.labelTitel.Name = "labelTitel";
            this.labelTitel.Size = new System.Drawing.Size(27, 13);
            this.labelTitel.TabIndex = 11;
            this.labelTitel.Text = "Titel";
            // 
            // textBoxGenre
            // 
            this.textBoxGenre.Location = new System.Drawing.Point(456, 319);
            this.textBoxGenre.Name = "textBoxGenre";
            this.textBoxGenre.Size = new System.Drawing.Size(327, 20);
            this.textBoxGenre.TabIndex = 10;
            this.textBoxGenre.Text = "Science Fiction";
            // 
            // textBoxOriginaltitel
            // 
            this.textBoxOriginaltitel.Location = new System.Drawing.Point(456, 256);
            this.textBoxOriginaltitel.Name = "textBoxOriginaltitel";
            this.textBoxOriginaltitel.Size = new System.Drawing.Size(327, 20);
            this.textBoxOriginaltitel.TabIndex = 9;
            this.textBoxOriginaltitel.Text = "The Hitchhiker’s Guide to the Galaxy";
            // 
            // textBoxErscheinungsjahr
            // 
            this.textBoxErscheinungsjahr.Location = new System.Drawing.Point(456, 192);
            this.textBoxErscheinungsjahr.Name = "textBoxErscheinungsjahr";
            this.textBoxErscheinungsjahr.Size = new System.Drawing.Size(327, 20);
            this.textBoxErscheinungsjahr.TabIndex = 8;
            this.textBoxErscheinungsjahr.Text = "1980";
            // 
            // textBoxAutor
            // 
            this.textBoxAutor.Location = new System.Drawing.Point(456, 135);
            this.textBoxAutor.Name = "textBoxAutor";
            this.textBoxAutor.Size = new System.Drawing.Size(327, 20);
            this.textBoxAutor.TabIndex = 7;
            this.textBoxAutor.Text = "Douglas Adams";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.panel4.Location = new System.Drawing.Point(13, 3);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(207, 59);
            this.panel4.TabIndex = 3;
            // 
            // btnAbbrechen
            // 
            this.btnAbbrechen.BackColor = System.Drawing.Color.Thistle;
            this.btnAbbrechen.Image = global::KURZBEIN_DATENERFASSUNG.Properties.Resources.StarTrek;
            this.btnAbbrechen.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAbbrechen.Location = new System.Drawing.Point(13, 229);
            this.btnAbbrechen.Name = "btnAbbrechen";
            this.btnAbbrechen.Size = new System.Drawing.Size(207, 72);
            this.btnAbbrechen.TabIndex = 6;
            this.btnAbbrechen.Text = "  Abbrechen";
            this.btnAbbrechen.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnAbbrechen.UseVisualStyleBackColor = false;
            this.btnAbbrechen.Click += new System.EventHandler(this.btnAbbrechen_Click);
            // 
            // btnSpeichern
            // 
            this.btnSpeichern.BackColor = System.Drawing.Color.Thistle;
            this.btnSpeichern.Image = global::KURZBEIN_DATENERFASSUNG.Properties.Resources.StarTrek;
            this.btnSpeichern.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSpeichern.Location = new System.Drawing.Point(13, 108);
            this.btnSpeichern.Name = "btnSpeichern";
            this.btnSpeichern.Size = new System.Drawing.Size(207, 72);
            this.btnSpeichern.TabIndex = 5;
            this.btnSpeichern.Text = "  Speichern";
            this.btnSpeichern.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnSpeichern.UseVisualStyleBackColor = false;
            this.btnSpeichern.Click += new System.EventHandler(this.btnSpeichern_Click);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.panel5.Location = new System.Drawing.Point(13, 360);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(207, 59);
            this.panel5.TabIndex = 4;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.panel3.Location = new System.Drawing.Point(291, 360);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(495, 59);
            this.panel3.TabIndex = 2;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.panel2.Location = new System.Drawing.Point(291, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(495, 59);
            this.panel2.TabIndex = 1;
            // 
            // textBoxTitel
            // 
            this.textBoxTitel.Location = new System.Drawing.Point(456, 80);
            this.textBoxTitel.Name = "textBoxTitel";
            this.textBoxTitel.Size = new System.Drawing.Size(327, 20);
            this.textBoxTitel.TabIndex = 0;
            this.textBoxTitel.Text = "Per Anhalter durch die Galaxis";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel1);
            this.Name = "Form2";
            this.Text = "Form2";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox textBoxTitel;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btnAbbrechen;
        private System.Windows.Forms.Button btnSpeichern;
        private System.Windows.Forms.TextBox textBoxGenre;
        private System.Windows.Forms.TextBox textBoxOriginaltitel;
        private System.Windows.Forms.TextBox textBoxErscheinungsjahr;
        private System.Windows.Forms.TextBox textBoxAutor;
        private System.Windows.Forms.Label labelGenre;
        private System.Windows.Forms.Label labelOriginaltitel;
        private System.Windows.Forms.Label labelErscheinungsjahr;
        private System.Windows.Forms.Label labelAutor;
        private System.Windows.Forms.Label labelTitel;
    }
}