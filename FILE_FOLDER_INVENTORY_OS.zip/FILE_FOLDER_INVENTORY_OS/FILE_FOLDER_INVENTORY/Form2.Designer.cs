﻿namespace FILE_FOLDER_INVENTORY
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnAbbrechen = new System.Windows.Forms.Button();
            this.btnSpeichern = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.textBoxOrdner_Nr = new System.Windows.Forms.TextBox();
            this.textBoxRaum = new System.Windows.Forms.TextBox();
            this.textBoxAbteilung = new System.Windows.Forms.TextBox();
            this.textBoxStatus_ = new System.Windows.Forms.TextBox();
            this.textBoxErfasst_durch = new System.Windows.Forms.TextBox();
            this.textBoxBeschriftung = new System.Windows.Forms.TextBox();
            this.textBoxEbene = new System.Windows.Forms.TextBox();
            this.textBoxRegal = new System.Windows.Forms.TextBox();
            this.textBoxErfasst_am = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.textBoxJahr = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.textBoxAuftrags_Nr = new System.Windows.Forms.TextBox();
            this.textBoxAbteilungsleiter = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel1.Controls.Add(this.btnAbbrechen);
            this.panel1.Controls.Add(this.btnSpeichern);
            this.panel1.Location = new System.Drawing.Point(12, 62);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(108, 566);
            this.panel1.TabIndex = 0;
            // 
            // btnAbbrechen
            // 
            this.btnAbbrechen.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.btnAbbrechen.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAbbrechen.Location = new System.Drawing.Point(3, 500);
            this.btnAbbrechen.Name = "btnAbbrechen";
            this.btnAbbrechen.Size = new System.Drawing.Size(102, 58);
            this.btnAbbrechen.TabIndex = 1;
            this.btnAbbrechen.Text = "Back";
            this.btnAbbrechen.UseVisualStyleBackColor = false;
            this.btnAbbrechen.Click += new System.EventHandler(this.btnAbbrechen_Click);
            // 
            // btnSpeichern
            // 
            this.btnSpeichern.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.btnSpeichern.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSpeichern.Location = new System.Drawing.Point(3, 3);
            this.btnSpeichern.Name = "btnSpeichern";
            this.btnSpeichern.Size = new System.Drawing.Size(102, 58);
            this.btnSpeichern.TabIndex = 0;
            this.btnSpeichern.Text = "Save";
            this.btnSpeichern.UseVisualStyleBackColor = false;
            this.btnSpeichern.Click += new System.EventHandler(this.btnSpeichern_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel3.Controls.Add(this.label10);
            this.panel3.Location = new System.Drawing.Point(12, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1075, 34);
            this.panel3.TabIndex = 0;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(478, 6);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(164, 25);
            this.label10.TabIndex = 0;
            this.label10.Text = "FILE_FOLDER\r\n";
            // 
            // textBoxOrdner_Nr
            // 
            this.textBoxOrdner_Nr.Location = new System.Drawing.Point(13, 47);
            this.textBoxOrdner_Nr.Name = "textBoxOrdner_Nr";
            this.textBoxOrdner_Nr.Size = new System.Drawing.Size(112, 20);
            this.textBoxOrdner_Nr.TabIndex = 1;
            // 
            // textBoxRaum
            // 
            this.textBoxRaum.Location = new System.Drawing.Point(259, 47);
            this.textBoxRaum.Name = "textBoxRaum";
            this.textBoxRaum.Size = new System.Drawing.Size(100, 20);
            this.textBoxRaum.TabIndex = 2;
            // 
            // textBoxAbteilung
            // 
            this.textBoxAbteilung.Location = new System.Drawing.Point(13, 62);
            this.textBoxAbteilung.Name = "textBoxAbteilung";
            this.textBoxAbteilung.Size = new System.Drawing.Size(307, 20);
            this.textBoxAbteilung.TabIndex = 5;
            // 
            // textBoxStatus_
            // 
            this.textBoxStatus_.Location = new System.Drawing.Point(572, 151);
            this.textBoxStatus_.Name = "textBoxStatus_";
            this.textBoxStatus_.Size = new System.Drawing.Size(307, 20);
            this.textBoxStatus_.TabIndex = 10;
            // 
            // textBoxErfasst_durch
            // 
            this.textBoxErfasst_durch.Location = new System.Drawing.Point(229, 151);
            this.textBoxErfasst_durch.Name = "textBoxErfasst_durch";
            this.textBoxErfasst_durch.Size = new System.Drawing.Size(277, 20);
            this.textBoxErfasst_durch.TabIndex = 9;
            // 
            // textBoxBeschriftung
            // 
            this.textBoxBeschriftung.Location = new System.Drawing.Point(9, 62);
            this.textBoxBeschriftung.Name = "textBoxBeschriftung";
            this.textBoxBeschriftung.Size = new System.Drawing.Size(870, 20);
            this.textBoxBeschriftung.TabIndex = 7;
            // 
            // textBoxEbene
            // 
            this.textBoxEbene.Location = new System.Drawing.Point(783, 47);
            this.textBoxEbene.Name = "textBoxEbene";
            this.textBoxEbene.Size = new System.Drawing.Size(100, 20);
            this.textBoxEbene.TabIndex = 4;
            // 
            // textBoxRegal
            // 
            this.textBoxRegal.Location = new System.Drawing.Point(520, 47);
            this.textBoxRegal.Name = "textBoxRegal";
            this.textBoxRegal.Size = new System.Drawing.Size(100, 20);
            this.textBoxRegal.TabIndex = 3;
            // 
            // textBoxErfasst_am
            // 
            this.textBoxErfasst_am.Location = new System.Drawing.Point(9, 151);
            this.textBoxErfasst_am.Name = "textBoxErfasst_am";
            this.textBoxErfasst_am.Size = new System.Drawing.Size(167, 20);
            this.textBoxErfasst_am.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(10, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(145, 15);
            this.label1.TabIndex = 10;
            this.label1.Text = "Ordner Nr (folder no.)";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(256, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(92, 15);
            this.label2.TabIndex = 11;
            this.label2.Text = "Raum (room)";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(517, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(90, 15);
            this.label3.TabIndex = 12;
            this.label3.Text = "Regal (shelf)";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(780, 16);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(92, 15);
            this.label4.TabIndex = 13;
            this.label4.Text = "Ebene (level)";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(10, 25);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(154, 15);
            this.label5.TabIndex = 14;
            this.label5.Text = "Abteilung (department)";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(6, 31);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(153, 15);
            this.label6.TabIndex = 15;
            this.label6.Text = "Beschriftung (labeling)";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(6, 123);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(137, 15);
            this.label7.TabIndex = 16;
            this.label7.Text = "Erfasst_am (filed at)";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(226, 123);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(155, 15);
            this.label8.TabIndex = 17;
            this.label8.Text = "Erfasst_durch (filed by)";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(569, 127);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(47, 15);
            this.label9.TabIndex = 18;
            this.label9.Text = "Status";
            // 
            // textBoxJahr
            // 
            this.textBoxJahr.Location = new System.Drawing.Point(9, 230);
            this.textBoxJahr.Name = "textBoxJahr";
            this.textBoxJahr.Size = new System.Drawing.Size(167, 20);
            this.textBoxJahr.TabIndex = 11;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(6, 205);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(76, 15);
            this.label11.TabIndex = 21;
            this.label11.Text = "Jahr (year)";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(226, 205);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(150, 15);
            this.label12.TabIndex = 22;
            this.label12.Text = "Auftrags Nr (order no.)";
            // 
            // textBoxAuftrags_Nr
            // 
            this.textBoxAuftrags_Nr.Location = new System.Drawing.Point(229, 230);
            this.textBoxAuftrags_Nr.Name = "textBoxAuftrags_Nr";
            this.textBoxAuftrags_Nr.Size = new System.Drawing.Size(277, 20);
            this.textBoxAuftrags_Nr.TabIndex = 12;
            // 
            // textBoxAbteilungsleiter
            // 
            this.textBoxAbteilungsleiter.Location = new System.Drawing.Point(13, 146);
            this.textBoxAbteilungsleiter.Name = "textBoxAbteilungsleiter";
            this.textBoxAbteilungsleiter.Size = new System.Drawing.Size(497, 20);
            this.textBoxAbteilungsleiter.TabIndex = 6;
            this.textBoxAbteilungsleiter.TextChanged += new System.EventHandler(this.textBoxAbteilungsleiter_TextChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(10, 112);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(246, 15);
            this.label13.TabIndex = 25;
            this.label13.Text = "Abteilungsleiter (head of department)";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(508, 43);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(98, 16);
            this.label14.TabIndex = 1;
            this.label14.Text = "Data Capture";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label14.Click += new System.EventHandler(this.label14_Click);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox1.Location = new System.Drawing.Point(576, 25);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(153, 20);
            this.checkBox1.TabIndex = 26;
            this.checkBox1.Text = "Geprüft (reviewed)";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox2.Location = new System.Drawing.Point(576, 78);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(136, 20);
            this.checkBox2.TabIndex = 27;
            this.checkBox2.Text = "Behalten (keep)";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox3.Location = new System.Drawing.Point(576, 137);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(169, 20);
            this.checkBox3.TabIndex = 28;
            this.checkBox3.Text = "Archivieren (archive)";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox4.Location = new System.Drawing.Point(763, 137);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(165, 20);
            this.checkBox4.TabIndex = 29;
            this.checkBox4.Text = "Archiviert (archived)";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.textBoxOrdner_Nr);
            this.panel2.Controls.Add(this.textBoxRaum);
            this.panel2.Controls.Add(this.textBoxEbene);
            this.panel2.Controls.Add(this.textBoxRegal);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Location = new System.Drawing.Point(126, 62);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(961, 81);
            this.panel2.TabIndex = 30;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel4.Controls.Add(this.label5);
            this.panel4.Controls.Add(this.textBoxAbteilung);
            this.panel4.Controls.Add(this.checkBox4);
            this.panel4.Controls.Add(this.textBoxAbteilungsleiter);
            this.panel4.Controls.Add(this.label13);
            this.panel4.Controls.Add(this.checkBox3);
            this.panel4.Controls.Add(this.checkBox1);
            this.panel4.Controls.Add(this.checkBox2);
            this.panel4.Location = new System.Drawing.Point(126, 149);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(961, 196);
            this.panel4.TabIndex = 31;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel5.Controls.Add(this.label6);
            this.panel5.Controls.Add(this.textBoxStatus_);
            this.panel5.Controls.Add(this.textBoxErfasst_durch);
            this.panel5.Controls.Add(this.textBoxBeschriftung);
            this.panel5.Controls.Add(this.textBoxAuftrags_Nr);
            this.panel5.Controls.Add(this.textBoxErfasst_am);
            this.panel5.Controls.Add(this.label12);
            this.panel5.Controls.Add(this.label7);
            this.panel5.Controls.Add(this.label11);
            this.panel5.Controls.Add(this.label8);
            this.panel5.Controls.Add(this.textBoxJahr);
            this.panel5.Controls.Add(this.label9);
            this.panel5.Location = new System.Drawing.Point(126, 354);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(961, 274);
            this.panel5.TabIndex = 32;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(1100, 632);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Name = "Form2";
            this.Text = "Data Capture";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.panel1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox textBoxOrdner_Nr;
        private System.Windows.Forms.TextBox textBoxRaum;
        private System.Windows.Forms.TextBox textBoxAbteilung;
        private System.Windows.Forms.TextBox textBoxStatus_;
        private System.Windows.Forms.TextBox textBoxErfasst_durch;
        private System.Windows.Forms.TextBox textBoxBeschriftung;
        private System.Windows.Forms.TextBox textBoxEbene;
        private System.Windows.Forms.TextBox textBoxRegal;
        private System.Windows.Forms.TextBox textBoxErfasst_am;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnAbbrechen;
        private System.Windows.Forms.Button btnSpeichern;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBoxJahr;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBoxAuftrags_Nr;
        private System.Windows.Forms.TextBox textBoxAbteilungsleiter;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
    }
}